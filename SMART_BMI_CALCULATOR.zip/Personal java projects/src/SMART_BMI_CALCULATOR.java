import java.util.*;
import java.io.*;
import java.math.*;
public class SMART_BMI_CALCULATOR {
  public static void main(String[] args) throws IOException{
    //Initializing the fastest input tool, used in competitive programming.
    BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    StringTokenizer st;

    System.out.println("Your Body Mass Index, or BMI is a representation of how healthy you are. \n\nA BMI of 25.0 or more is overweight, while the healthy range is 18.5 to 24.9. \n\nLet's see how you score! \n\n\nDISCLAIMER: I AM NOT A DOCTOR. ANYTHING IN THIS PROGRAM IS PURELY ADVICE BASED ON THE CODER'S CURRENT KNOWLEDGE. CONSULT A DOCTOR IF YOU ARE MAKING DRASTIC CHANGES. ADDITIONALLY, BMI USUALLY ONLY APPLIES TO ADULTS 18 TO 65, HOWEVER, YOU MAY STILL USE THIS PROGRAM TO SEE HOW YOU SCORE. THANK YOU!");

    System.out.println("Please enter your weight in kilograms, and height in centimeters, on seperate lines.");

    //Inputting weight and height
    st = new StringTokenizer(br.readLine());
    double w = Double.parseDouble(st.nextToken());
    
    st = new StringTokenizer(br.readLine());
    double h = Double.parseDouble(st.nextToken());

    //Calculating BMI
      double hm = h/100;
      double BMI = w/(hm*hm);
    

    //Using BigDecimal and setScale to round BMI to hundreds
    BigDecimal bd = new BigDecimal(BMI).setScale(2, RoundingMode.HALF_UP);
    double rBMI = bd.doubleValue();

    System.out.println("Your bmi is: "+rBMI);
//Just for reference as I was writing
//Underweight = <18
// Normal weight = 18�24.9
// Overweight = 25�29.9
// Obesity = BMI of 30 or greater


    if(rBMI<18.5 && rBMI>14.9){
     System.out.println("You are underweight. Don't worry though, there are ways to become healthier. First of all, consider starting a healthier, more balanced diet, consisting of lots of protien, vegetables, and also grains."); 
    }
    if(rBMI<15){
      System.out.println("You are severely underweight. Either you are trolling by inputting extreme values, or you need to get some help.");
    }
    if(rBMI>18 && rBMI<24.9){
      System.out.println("Your weight is normal! Great job staying healthy. Remember to get lots of excercise and eat a balanced diet.");
    }
    if(rBMI>25 && rBMI<29.9){
      System.out.println("You are overweight. Don't worry though, there are ways to become healthier. First of all, consider starting a healthier, more balanced diet. Also, try to excercise for at least an hour every day. Also consider eating less junk food. Live life happily and healthily!");
    }
    if(rBMI>30){
      System.out.println("You are severely obese. Either you are trolling by inputting extreme values, or you need to get some help.");
    }

  }
}